#!/data/data/com.termux/files/usr/bin/sh
cd /data/data/com.termux/files/home/capcut_offline_project/backend
exec gunicorn -w 4 --threads 4 -b 0.0.0.0:5002 --timeout 300 --reload app:app
