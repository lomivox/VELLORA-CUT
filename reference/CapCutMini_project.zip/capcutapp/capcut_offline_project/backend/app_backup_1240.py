from flask import send_from_directory, Flask, request, jsonify, render_template, send_file
from werkzeug.utils import secure_filename
import os, subprocess, shutil, logging

app = Flask(__name__)
logging.basicConfig(level=logging.INFO)

UPLOAD_FOLDER = "/data/data/com.termux/files/home/capcut_offline_project/uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

ALLOWED_VIDEO = {'mp4', 'mov', 'avi', 'mkv', '3gp', 'webm'}
ALLOWED_AUDIO = {'mp3', 'aac', 'wav', 'm4a', 'ogg'}
ALLOWED_OVERLAY = {'mp4', 'mov', 'avi', 'mkv', '3gp', 'webm', 'png', 'jpg', 'jpeg', 'gif', 'webp'}

def allowed_file(filename, allowed):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in allowed

def file_path(filename):
    return os.path.join(UPLOAD_FOLDER, filename)

def run_ffmpeg(args):
    result = subprocess.run(args, capture_output=True, text=True)
    if result.returncode != 0:
        logging.error(f"FFmpeg error: {result.stderr[-500:]}")
        return False
    return True

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/upload", methods=["POST"])
def upload():
    try:
        if 'file' not in request.files:
            return jsonify({"status": "error", "error": "No file provided"}), 400
        file = request.files["file"]
        if not file.filename:
            return jsonify({"status": "error", "error": "Empty filename"}), 400
        if not allowed_file(file.filename, ALLOWED_VIDEO):
            return jsonify({"status": "error", "error": "Invalid video format"}), 400
        filename = secure_filename(file.filename)
        path = file_path(filename)
        file.save(path)
        return jsonify({"status": "success", "file": filename})
    except Exception as e:
        logging.error(f"Upload error: {e}")
        return jsonify({"status": "error", "error": str(e)}), 500

@app.route("/upload_audio", methods=["POST"])
def upload_audio():
    try:
        if 'file' not in request.files:
            return jsonify({"status": "error", "error": "No file provided"}), 400
        file = request.files["file"]
        if not file.filename:
            return jsonify({"status": "error", "error": "Empty filename"}), 400
        if not allowed_file(file.filename, ALLOWED_AUDIO):
            return jsonify({"status": "error", "error": "Invalid audio format"}), 400
        filename = secure_filename(file.filename)
        path = file_path(filename)
        file.save(path)
        return jsonify({"status": "success", "file": filename})
    except Exception as e:
        logging.error(f"Audio upload error: {e}")
        return jsonify({"status": "error", "error": str(e)}), 500

@app.route("/uploads/<filename>")
def serve_upload(filename):
    return send_from_directory(UPLOAD_FOLDER, filename)

@app.route("/upload_overlay", methods=["POST"])
def upload_overlay():
    try:
        if 'file' not in request.files:
            return jsonify({"status": "error", "error": "No file provided"}), 400
        file = request.files["file"]
        if not file.filename:
            return jsonify({"status": "error", "error": "Empty filename"}), 400
        if not allowed_file(file.filename, ALLOWED_OVERLAY):
            return jsonify({"status": "error", "error": "Invalid overlay format"}), 400
        filename = secure_filename(file.filename)
        path = file_path(filename)
        file.save(path)
        ext = filename.rsplit('.', 1)[1].lower()
        is_image = ext in {'png','jpg','jpeg','gif','webp'}
        return jsonify({"status": "success", "file": filename, "type": "image" if is_image else "video"})
    except Exception as e:
        logging.error(f"Overlay upload error: {e}")
        return jsonify({"status": "error", "error": str(e)}), 500

@app.route("/export", methods=["POST"])
def export_video():
    try:
        data = request.json
        if not data or not data.get("file"):
            return jsonify({"status": "error", "error": "No file specified"}), 400

        src = file_path(data["file"])
        if not os.path.exists(src):
            return jsonify({"status": "error", "error": "Source file not found"}), 404

        tmp = src
        step = 0

        def next_tmp(name):
            nonlocal step
            step += 1
            return file_path(f"ex_{step}_{name}.mp4")

        # Step 0: Ratio/Crop
        ratio = data.get("ratio", "original")
        ratio_map = {
            "9:16":   "scale=1080:1920:force_original_aspect_ratio=decrease,pad=1080:1920:(ow-iw)/2:(oh-ih)/2",
            "16:9":   "scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2",
            "1:1":    "scale=1080:1080:force_original_aspect_ratio=decrease,pad=1080:1080:(ow-iw)/2:(oh-ih)/2",
            "4:3":    "scale=1440:1080:force_original_aspect_ratio=decrease,pad=1440:1080:(ow-iw)/2:(oh-ih)/2",
            "3:4":    "scale=1080:1440:force_original_aspect_ratio=decrease,pad=1080:1440:(ow-iw)/2:(oh-ih)/2",
            "2:1":    "scale=2160:1080:force_original_aspect_ratio=decrease,pad=2160:1080:(ow-iw)/2:(oh-ih)/2",
            "1:2":    "scale=1080:2160:force_original_aspect_ratio=decrease,pad=1080:2160:(ow-iw)/2:(oh-ih)/2",
            "2.35:1": "scale=2538:1080:force_original_aspect_ratio=decrease,pad=2538:1080:(ow-iw)/2:(oh-ih)/2",
            "1.85:1": "scale=1998:1080:force_original_aspect_ratio=decrease,pad=1998:1080:(ow-iw)/2:(oh-ih)/2",
            "128:27": "scale=2560:540:force_original_aspect_ratio=decrease,pad=2560:540:(ow-iw)/2:(oh-ih)/2",
        }
        if ratio in ratio_map:
            out = next_tmp("ratio")
            ok = run_ffmpeg(["ffmpeg", "-y", "-i", tmp,
                "-vf", ratio_map[ratio],
                "-preset", "ultrafast", "-crf", "28",
                "-codec:a", "copy", out])
            if not ok:
                return jsonify({"status": "error", "error": "Ratio change failed"}), 500
            tmp = out

        # Step 1: Clips array trim+concat
        clips_data = data.get("clips", [])
        if clips_data and len(clips_data) > 0:
            trimmed_parts = []
            for i, clip in enumerate(clips_data):
                clip_file = clip.get("file", data["file"])
                clip_src = file_path(clip_file)
                if not os.path.exists(clip_src):
                    clip_src = tmp
                cs = float(clip.get("start", 0))
                ce = float(clip.get("end", 0))
                dur = ce - cs
                if dur <= 0:
                    continue
                part_out = file_path(f"ex_clip_{i}.mp4")
                ok = run_ffmpeg(["ffmpeg", "-y", "-i", clip_src,
                    "-ss", str(cs), "-t", str(dur),
                    "-c", "copy", part_out])
                if ok:
                    trimmed_parts.append(part_out)
            if len(trimmed_parts) == 1:
                tmp = trimmed_parts[0]
            elif len(trimmed_parts) > 1:
                concat_list = file_path("concat_list.txt")
                with open(concat_list, "w") as cf:
                    for p in trimmed_parts:
                        cf.write(f"file '{p}'\n")
                out = next_tmp("concat")
                ok = run_ffmpeg(["ffmpeg", "-y", "-f", "concat", "-safe", "0",
                    "-i", concat_list, "-c", "copy", out])
                if not ok:
                    return jsonify({"status": "error", "error": "Concat failed"}), 500
                tmp = out
        else:
            # fallback: purana trim system
            trim_start = max(0, int(data.get("trim_start", 0)))
            trim_end = int(data.get("trim_end", 0))
            if trim_end > trim_start:
                out = next_tmp("trim")
                duration = trim_end - trim_start
                ok = run_ffmpeg(["ffmpeg", "-y", "-i", tmp,
                    "-ss", str(trim_start), "-t", str(duration),
                    "-c", "copy", out])
                if not ok:
                    return jsonify({"status": "error", "error": "Trim failed"}), 500
                tmp = out

        # Step 2: Speed
        speed = float(data.get("speed", 1.0))
        if speed != 1.0:
            out = next_tmp("speed")
            # atempo range: 0.5-2.0, chain filters for extreme speeds
            if speed < 0.5:
                atempo_filter = f"atempo=0.5,atempo={speed/0.5}"
            elif speed > 2.0:
                atempo_filter = f"atempo=2.0,atempo={speed/2.0}"
            else:
                atempo_filter = f"atempo={speed}"
            ok = run_ffmpeg(["ffmpeg", "-y", "-i", tmp,
                "-filter_complex",
                f"[0:v]setpts={1/speed}*PTS[v];[0:a]{atempo_filter}[a]",
                "-map", "[v]", "-map", "[a]",
                "-preset", "ultrafast", out])
            if not ok:
                return jsonify({"status": "error", "error": "Speed change failed"}), 500
            tmp = out

        # Step 3: Filter
        ftype = data.get("filter", "none")
        if ftype != "none":
            out = next_tmp("filter")
            b = data.get("brightness", 0)
            c = data.get("contrast", 1)
            s = data.get("saturation", 1)
            filter_map = {
                "grayscale": "hue=s=0",
                "warm":      "colorbalance=rs=0.3:gs=0.1:bs=-0.3",
                "cool":      "colorbalance=rs=-0.3:gs=0.1:bs=0.3",
                "vintage":   "curves=vintage",
                "custom":    f"eq=brightness={b}:contrast={c}:saturation={s}",
            }
            vf = filter_map.get(ftype, "hue=s=0")
            ok = run_ffmpeg(["ffmpeg", "-y", "-i", tmp,
                "-vf", vf, "-preset", "ultrafast",
                "-crf", "28", "-codec:a", "copy", out])
            if not ok:
                return jsonify({"status": "error", "error": "Filter failed"}), 500
            tmp = out

        # Step 4: Text Overlay
        if data.get("text_enabled") and data.get("text", "").strip():
            out = next_tmp("text")
            pos = data.get("text_pos", "bottom")
            y = "50" if pos == "top" else "h-100" if pos == "bottom" else "(h-text_h)/2"
            txt = data["text"].strip().replace("'", "\u2019")
            fontsize = int(data.get("fontsize", 48))
            color = data.get("text_color", "white")
            font_family = data.get("font_family", "Roboto")
            font_map = {
                "Roboto": "/system/fonts/Roboto-Regular.ttf",
                "Roboto Bold": "/system/fonts/DroidSans-Bold.ttf",
                "Noto Serif": "/system/fonts/NotoSerif-Bold.ttf",
                "Source Sans Pro": "/system/fonts/SourceSansPro-Bold.ttf",
                "Mono": "/system/fonts/CutiveMono.ttf",
                "Droid Sans": "/system/fonts/DroidSans.ttf",
                "Lobster": "fonts/Lobster.ttf",
                "Pacifico": "fonts/Pacifico.ttf",
            }
            fontfile = font_map.get(font_family, "/system/fonts/Roboto-Regular.ttf")
            ok = run_ffmpeg(["ffmpeg", "-y", "-i", tmp,
                "-vf", f"drawtext=fontfile={fontfile}:text='{txt}':fontsize={fontsize}:fontcolor={color}:x=(w-text_w)/2:y={y}:box=1:boxcolor=black@0.5:boxborderw=5",
                "-preset", "ultrafast", "-crf", "28",
                "-codec:a", "copy", out])
            if not ok:
                return jsonify({"status": "error", "error": "Text overlay failed"}), 500
            tmp = out

        # Step 5: Background Music
        if data.get("audio_enabled") and data.get("audio", ""):
            audio_src = file_path(data["audio"])
            if not os.path.exists(audio_src):
                return jsonify({"status": "error", "error": "Audio file not found"}), 404
            out = next_tmp("audio")
            orig_vol = float(data.get("orig_vol", 0.5))
            music_vol = float(data.get("music_vol", 1.0))
            # Check if video has audio track
            probe = subprocess.run(
                ["ffprobe", "-v", "error", "-select_streams", "a",
                 "-show_entries", "stream=codec_type",
                 "-of", "default=noprint_wrappers=1:nokey=1", tmp],
                capture_output=True, text=True
            )
            has_audio = "audio" in probe.stdout
            if has_audio:
                ok = run_ffmpeg(["ffmpeg", "-y", "-i", tmp, "-i", audio_src,
                    "-filter_complex",
                    f"[0:a]volume={orig_vol}[a1];[1:a]volume={music_vol}[a2];[a1][a2]amix=inputs=2:duration=first[aout]",
                    "-map", "0:v", "-map", "[aout]",
                    "-preset", "ultrafast", "-shortest", out])
            else:
                ok = run_ffmpeg(["ffmpeg", "-y", "-i", tmp, "-i", audio_src,
                    "-filter_complex",
                    f"[1:a]volume={music_vol}[aout]",
                    "-map", "0:v", "-map", "[aout]",
                    "-preset", "ultrafast", "-shortest", out])
            if not ok:
                return jsonify({"status": "error", "error": "Audio mix failed"}), 500
            tmp = out


        # Step 6: Rotate / Flip
        rotate = data.get("rotate", "none")
        if rotate != "none":
            out = next_tmp("rotate")
            rotate_map = {
                "90":    "transpose=1",
                "180":   "transpose=1,transpose=1",
                "270":   "transpose=2",
                "fliph": "hflip",
                "flipv": "vflip",
            }
            vf = rotate_map.get(rotate)
            if vf:
                ok = run_ffmpeg(["ffmpeg", "-y", "-i", tmp,
                    "-vf", vf, "-preset", "ultrafast",
                    "-crf", "28", "-codec:a", "copy", out])
                if not ok:
                    return jsonify({"status": "error", "error": "Rotate failed"}), 500
                tmp = out

        # Step 7: Video Volume
        video_vol = float(data.get("video_vol", 1.0))
        if video_vol != 1.0:
            out = next_tmp("vol")
            ok = run_ffmpeg(["ffmpeg", "-y", "-i", tmp,
                "-filter:a", f"volume={video_vol}",
                "-codec:v", "copy", out])
            if not ok:
                return jsonify({"status": "error", "error": "Volume change failed"}), 500
            tmp = out

        # Step 8: Noise Reduction
        noise_level = data.get("noise_level", "off")
        noise_map = {
            "light":  "afftdn=nf=-15",
            "medium": "afftdn=nf=-25",
            "heavy":  "afftdn=nf=-40",
        }
        if noise_level in noise_map:
            out = next_tmp("noise")
            ok = run_ffmpeg(["ffmpeg", "-y", "-i", tmp,
                "-af", noise_map[noise_level],
                "-codec:v", "copy", out])
            if not ok:
                return jsonify({"status": "error", "error": "Noise reduction failed"}), 500
            tmp = out

        # Step 9: Mute
        if data.get("mute"):
            out = next_tmp("mute")
            ok = run_ffmpeg(["ffmpeg", "-y", "-i", tmp,
                "-an", "-vcodec", "copy", out])
            if not ok:
                return jsonify({"status": "error", "error": "Mute failed"}), 500
            tmp = out

        # Step 8: Export Quality
        quality = data.get("quality", "720p")
        quality_map = {
            "480p":  ["-vf", "scale=854:480",  "-crf", "28"],
            "720p":  ["-vf", "scale=1280:720", "-crf", "23"],
            "1080p": ["-vf", "scale=1920:1080","-crf", "18"],
        }
        q_args = quality_map.get(quality, quality_map["720p"])
        out = next_tmp("quality")
        ok = run_ffmpeg(["ffmpeg", "-y", "-i", tmp,
            *q_args, "-preset", "ultrafast",
            "-codec:a", "copy", out])
        if not ok:
            return jsonify({"status": "error", "error": "Quality change failed"}), 500
        tmp = out
        # Step: Fade In / Out
        fade_in = float(data.get("fade_in", 0))
        fade_out = float(data.get("fade_out", 0))
        if fade_in > 0 or fade_out > 0:
            probe = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", tmp], capture_output=True, text=True)
            duration = float(probe.stdout.strip())
            vf_parts = []
            af_parts = []
            if fade_in > 0:
                vf_parts.append(f"fade=t=in:st=0:d={fade_in}")
                af_parts.append(f"afade=t=in:st=0:d={fade_in}")
            if fade_out > 0:
                vf_parts.append(f"fade=t=out:st={duration-fade_out}:d={fade_out}")
                af_parts.append(f"afade=t=out:st={duration-fade_out}:d={fade_out}")
            vf = ",".join(vf_parts) if vf_parts else "null"
            af = ",".join(af_parts) if af_parts else "anull"
            out = next_tmp("fade")
            ok = run_ffmpeg(["ffmpeg", "-y", "-i", tmp, "-vf", vf, "-af", af, "-preset", "ultrafast", "-crf", "28", out])
            if not ok:
                return jsonify({"status": "error", "error": "Fade failed"}), 500
            tmp = out

        # Final copy
        final = file_path("final_export.mp4")
        shutil.copy2(tmp, final)

        # Cleanup temp files
        for i in range(1, step + 1):
            for name in ["trim", "speed", "filter", "text", "audio", "rotate", "vol", "noise", "mute", "quality"]:
                f = file_path(f"ex_{i}_{name}.mp4")
                if os.path.exists(f):
                    os.remove(f)

        return jsonify({"status": "success", "file": "final_export.mp4"})

    except Exception as e:
        logging.error(f"Export error: {e}")
        return jsonify({"status": "error", "error": str(e)}), 500

@app.route("/thumbnails/<filename>")
def get_thumbnails(filename):
    try:
        path = file_path(filename)
        if not os.path.exists(path):
            return jsonify({"status": "error", "error": "File not found"}), 404

        safe_name = os.path.splitext(filename)[0]
        thumb_dir = os.path.join(UPLOAD_FOLDER, "thumbs_" + safe_name)

        # If thumbnails already exist, return cached list
        if os.path.isdir(thumb_dir):
            files = sorted(os.listdir(thumb_dir))
            if files:
                return jsonify({"status": "success", "thumbnails": files, "folder": "thumbs_" + safe_name})

        os.makedirs(thumb_dir, exist_ok=True)

        # Get duration
        result = subprocess.run(
            ["ffprobe", "-v", "error", "-show_entries", "format=duration",
             "-of", "default=noprint_wrappers=1:nokey=1", path],
            capture_output=True, text=True
        )
        try:
            duration = float(result.stdout.strip())
        except:
            duration = 10.0

        count = 10
        interval = duration / count if duration > 0 else 1

        for i in range(count):
            ts = i * interval
            out_file = os.path.join(thumb_dir, f"thumb_{i:02d}.jpg")
            run_ffmpeg(["ffmpeg", "-y", "-ss", str(ts), "-i", path,
                        "-frames:v", "1", "-vf", "scale=160:-1", out_file])

        files = sorted(os.listdir(thumb_dir))
        return jsonify({"status": "success", "thumbnails": files, "folder": "thumbs_" + safe_name, "duration": duration})
    except Exception as e:
        logging.error(f"Thumbnail error: {e}")
        return jsonify({"status": "error", "error": str(e)}), 500

@app.route("/thumb_img/<folder>/<filename>")
def serve_thumb(folder, filename):
    try:
        path = os.path.join(UPLOAD_FOLDER, folder, filename)
        if not os.path.exists(path):
            return jsonify({"status": "error", "error": "File not found"}), 404
        return send_file(path, mimetype="image/jpeg")
    except Exception as e:
        return jsonify({"status": "error", "error": str(e)}), 500

@app.route("/video/<filename>")
def serve_video(filename):
    try:
        path = file_path(filename)
        if not os.path.exists(path):
            return jsonify({"status": "error", "error": "File not found"}), 404
        return send_file(path, mimetype="video/mp4")
    except Exception as e:
        return jsonify({"status": "error", "error": str(e)}), 500

@app.route("/download/<filename>")
def download(filename):
    try:
        path = file_path(filename)
        if not os.path.exists(path):
            return jsonify({"status": "error", "error": "File not found"}), 404
        return send_file(path, as_attachment=True)
    except Exception as e:
        return jsonify({"status": "error", "error": str(e)}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5002)


@app.route("/waveform", methods=["POST"])
def get_waveform():
    try:
        data = request.get_json()
        filename = data.get("file")
        if not filename:
            return jsonify({"status": "error", "error": "No file"}), 400
        path = file_path(filename)
        if not os.path.exists(path):
            return jsonify({"status": "error", "error": "File not found"}), 404
        import subprocess, json
        result = subprocess.run([
            "ffprobe", "-v", "error", "-select_streams", "a:0",
            "-show_entries", "packet=pts_time,size",
            "-of", "json", path
        ], capture_output=True, text=True, timeout=30)
        packets = json.loads(result.stdout).get("packets", [])
        total = len(packets)
        samples = 100
        peaks = []
        if total > 0:
            chunk = max(1, total // samples)
            for i in range(0, total, chunk):
                group = packets[i:i+chunk]
                avg = sum(int(p.get("size", 0)) for p in group) / len(group)
                peaks.append(round(avg))
        max_peak = max(peaks) if peaks else 1
        normalized = [round(p / max_peak, 3) for p in peaks]
        return jsonify({"status": "success", "peaks": normalized})
    except Exception as e:
        logging.error(f"Waveform error: {e}")
        return jsonify({"status": "error", "error": str(e)}), 500

@app.route("/upload_cover", methods=["POST"])
def upload_cover():
    try:
        if 'file' not in request.files:
            return jsonify({"status": "error", "error": "No file"}), 400
        file = request.files["file"]
        if not file.filename:
            return jsonify({"status": "error", "error": "Empty filename"}), 400
        filename = secure_filename(file.filename)
        path = file_path(filename)
        file.save(path)
        return jsonify({"status": "success", "url": "/uploads/" + filename})
    except Exception as e:
        logging.error(f"Cover upload error: {e}")
        return jsonify({"status": "error", "error": str(e)}), 500

@app.route("/fade", methods=["POST"])
def fade():
    data = request.json
    fname = data["file"]
    fade_in = float(data.get("fade_in", 0))
    fade_out = float(data.get("fade_out", 0))
    input_path = os.path.join(UPLOAD_FOLDER, fname)
    output_path = os.path.join(UPLOAD_FOLDER, "fade_" + fname)

    # video duration get karo
    probe = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", input_path], capture_output=True, text=True)
    duration = float(probe.stdout.strip())

    vf_parts = []
    af_parts = []

    if fade_in > 0:
        vf_parts.append(f"fade=t=in:st=0:d={fade_in}")
        af_parts.append(f"afade=t=in:st=0:d={fade_in}")
    if fade_out > 0:
        vf_parts.append(f"fade=t=out:st={duration-fade_out}:d={fade_out}")
        af_parts.append(f"afade=t=out:st={duration-fade_out}:d={fade_out}")

    vf = ",".join(vf_parts) if vf_parts else "null"
    af = ",".join(af_parts) if af_parts else "anull"

    cmd = ["ffmpeg", "-y", "-i", input_path, "-vf", vf, "-af", af, "-preset", "ultrafast", "-crf", "28", output_path]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        return jsonify({"status": "error", "msg": result.stderr}), 500
    return jsonify({"status": "success", "file": "fade_" + fname})
