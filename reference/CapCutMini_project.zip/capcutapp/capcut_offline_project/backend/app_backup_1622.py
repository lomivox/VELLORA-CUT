from flask import Flask, request, jsonify, render_template, send_file
import os, subprocess, shutil, logging

app = Flask(__name__)
logging.basicConfig(level=logging.INFO)

UPLOAD_FOLDER = "/data/data/com.termux/files/home/capcut_offline_project/uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

ALLOWED_VIDEO = {'mp4', 'mov', 'avi', 'mkv', '3gp', 'webm'}
ALLOWED_AUDIO = {'mp3', 'aac', 'wav', 'm4a', 'ogg'}

def allowed_file(filename, allowed):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in allowed

def file_path(filename):
    return os.path.join(UPLOAD_FOLDER, filename)

def run_ffmpeg(args):
    result = subprocess.run(args, capture_output=True, text=True)
    if result.returncode != 0:
        logging.error(f"FFmpeg error: {result.stderr[-500:]}")
        return False
    return True

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/upload", methods=["POST"])
def upload():
    try:
        if 'file' not in request.files:
            return jsonify({"status": "error", "error": "No file provided"}), 400
        file = request.files["file"]
        if not file.filename:
            return jsonify({"status": "error", "error": "Empty filename"}), 400
        if not allowed_file(file.filename, ALLOWED_VIDEO):
            return jsonify({"status": "error", "error": "Invalid video format"}), 400
        path = file_path(file.filename)
        file.save(path)
        return jsonify({"status": "success", "file": file.filename})
    except Exception as e:
        logging.error(f"Upload error: {e}")
        return jsonify({"status": "error", "error": str(e)}), 500

@app.route("/upload_audio", methods=["POST"])
def upload_audio():
    try:
        if 'file' not in request.files:
            return jsonify({"status": "error", "error": "No file provided"}), 400
        file = request.files["file"]
        if not file.filename:
            return jsonify({"status": "error", "error": "Empty filename"}), 400
        if not allowed_file(file.filename, ALLOWED_AUDIO):
            return jsonify({"status": "error", "error": "Invalid audio format"}), 400
        path = file_path(file.filename)
        file.save(path)
        return jsonify({"status": "success", "file": file.filename})
    except Exception as e:
        logging.error(f"Audio upload error: {e}")
        return jsonify({"status": "error", "error": str(e)}), 500

@app.route("/export", methods=["POST"])
def export_video():
    try:
        data = request.json
        if not data or not data.get("file"):
            return jsonify({"status": "error", "error": "No file specified"}), 400

        src = file_path(data["file"])
        if not os.path.exists(src):
            return jsonify({"status": "error", "error": "Source file not found"}), 404

        tmp = src
        step = 0

        def next_tmp(name):
            nonlocal step
            step += 1
            return file_path(f"ex_{step}_{name}.mp4")

        # Step 1: Trim
        trim_start = max(0, int(data.get("trim_start", 0)))
        trim_end = int(data.get("trim_end", 0))
        if trim_end > trim_start:
            out = next_tmp("trim")
            duration = trim_end - trim_start
            ok = run_ffmpeg(["ffmpeg", "-y", "-i", tmp,
                "-ss", str(trim_start), "-t", str(duration),
                "-c", "copy", out])
            if not ok:
                return jsonify({"status": "error", "error": "Trim failed"}), 500
            tmp = out

        # Step 2: Speed
        speed = float(data.get("speed", 1.0))
        if speed != 1.0:
            out = next_tmp("speed")
            atempo = min(max(speed, 0.5), 2.0)
            ok = run_ffmpeg(["ffmpeg", "-y", "-i", tmp,
                "-filter_complex",
                f"[0:v]setpts={1/speed}*PTS[v];[0:a]atempo={atempo}[a]",
                "-map", "[v]", "-map", "[a]",
                "-preset", "ultrafast", out])
            if not ok:
                return jsonify({"status": "error", "error": "Speed change failed"}), 500
            tmp = out

        # Step 3: Filter
        ftype = data.get("filter", "none")
        if ftype != "none":
            out = next_tmp("filter")
            b = data.get("brightness", 0)
            c = data.get("contrast", 1)
            s = data.get("saturation", 1)
            filter_map = {
                "grayscale": "hue=s=0",
                "warm":      "colorbalance=rs=0.3:gs=0.1:bs=-0.3",
                "cool":      "colorbalance=rs=-0.3:gs=0.1:bs=0.3",
                "vintage":   "curves=vintage",
                "custom":    f"eq=brightness={b}:contrast={c}:saturation={s}",
            }
            vf = filter_map.get(ftype, "hue=s=0")
            ok = run_ffmpeg(["ffmpeg", "-y", "-i", tmp,
                "-vf", vf, "-preset", "ultrafast",
                "-crf", "28", "-codec:a", "copy", out])
            if not ok:
                return jsonify({"status": "error", "error": "Filter failed"}), 500
            tmp = out

        # Step 4: Text Overlay
        if data.get("text_enabled") and data.get("text", "").strip():
            out = next_tmp("text")
            pos = data.get("text_pos", "bottom")
            y = "50" if pos == "top" else "h-100" if pos == "bottom" else "(h-text_h)/2"
            txt = data["text"].strip().replace("'", "\u2019")
            fontsize = int(data.get("fontsize", 48))
            color = data.get("text_color", "white")
            ok = run_ffmpeg(["ffmpeg", "-y", "-i", tmp,
                "-vf", f"drawtext=text='{txt}':fontsize={fontsize}:fontcolor={color}:x=(w-text_w)/2:y={y}:box=1:boxcolor=black@0.5:boxborderw=5",
                "-preset", "ultrafast", "-crf", "28",
                "-codec:a", "copy", out])
            if not ok:
                return jsonify({"status": "error", "error": "Text overlay failed"}), 500
            tmp = out

        # Step 5: Background Music
        if data.get("audio_enabled") and data.get("audio", ""):
            audio_src = file_path(data["audio"])
            if not os.path.exists(audio_src):
                return jsonify({"status": "error", "error": "Audio file not found"}), 404
            out = next_tmp("audio")
            orig_vol = float(data.get("orig_vol", 0.5))
            music_vol = float(data.get("music_vol", 1.0))
            ok = run_ffmpeg(["ffmpeg", "-y", "-i", tmp, "-i", audio_src,
                "-filter_complex",
                f"[0:a]volume={orig_vol}[a1];[1:a]volume={music_vol}[a2];[a1][a2]amix=inputs=2:duration=first[aout]",
                "-map", "0:v", "-map", "[aout]",
                "-preset", "ultrafast", "-shortest", out])
            if not ok:
                return jsonify({"status": "error", "error": "Audio mix failed"}), 500
            tmp = out


        # Step 6: Rotate / Flip
        rotate = data.get("rotate", "none")
        if rotate != "none":
            out = next_tmp("rotate")
            rotate_map = {
                "90":    "transpose=1",
                "180":   "transpose=1,transpose=1",
                "270":   "transpose=2",
                "fliph": "hflip",
                "flipv": "vflip",
            }
            vf = rotate_map.get(rotate)
            if vf:
                ok = run_ffmpeg(["ffmpeg", "-y", "-i", tmp,
                    "-vf", vf, "-preset", "ultrafast",
                    "-crf", "28", "-codec:a", "copy", out])
                if not ok:
                    return jsonify({"status": "error", "error": "Rotate failed"}), 500
                tmp = out

        # Step 7: Video Volume
        video_vol = float(data.get("video_vol", 1.0))
        if video_vol != 1.0:
            out = next_tmp("vol")
            ok = run_ffmpeg(["ffmpeg", "-y", "-i", tmp,
                "-filter:a", f"volume={video_vol}",
                "-codec:v", "copy", out])
            if not ok:
                return jsonify({"status": "error", "error": "Volume change failed"}), 500
            tmp = out

        # Step 8: Noise Reduction
        noise_level = data.get("noise_level", "off")
        noise_map = {
            "light":  "afftdn=nf=-15",
            "medium": "afftdn=nf=-25",
            "heavy":  "afftdn=nf=-40",
        }
        if noise_level in noise_map:
            out = next_tmp("noise")
            ok = run_ffmpeg(["ffmpeg", "-y", "-i", tmp,
                "-af", noise_map[noise_level],
                "-codec:v", "copy", out])
            if not ok:
                return jsonify({"status": "error", "error": "Noise reduction failed"}), 500
            tmp = out

        # Step 9: Mute
        if data.get("mute"):
            out = next_tmp("mute")
            ok = run_ffmpeg(["ffmpeg", "-y", "-i", tmp,
                "-an", "-vcodec", "copy", out])
            if not ok:
                return jsonify({"status": "error", "error": "Mute failed"}), 500
            tmp = out

        # Step 8: Export Quality
        quality = data.get("quality", "720p")
        quality_map = {
            "480p":  ["-vf", "scale=854:480",  "-crf", "28"],
            "720p":  ["-vf", "scale=1280:720", "-crf", "23"],
            "1080p": ["-vf", "scale=1920:1080","-crf", "18"],
        }
        q_args = quality_map.get(quality, quality_map["720p"])
        out = next_tmp("quality")
        ok = run_ffmpeg(["ffmpeg", "-y", "-i", tmp,
            *q_args, "-preset", "ultrafast",
            "-codec:a", "copy", out])
        if not ok:
            return jsonify({"status": "error", "error": "Quality change failed"}), 500
        tmp = out
        # Final copy
        final = file_path("final_export.mp4")
        shutil.copy2(tmp, final)

        # Cleanup temp files
        for i in range(1, step + 1):
            for name in ["trim", "speed", "filter", "text", "audio"]:
                f = file_path(f"ex_{i}_{name}.mp4")
                if os.path.exists(f):
                    os.remove(f)

        return jsonify({"status": "success", "file": "final_export.mp4"})

    except Exception as e:
        logging.error(f"Export error: {e}")
        return jsonify({"status": "error", "error": str(e)}), 500

@app.route("/video/<filename>")
def serve_video(filename):
    try:
        path = file_path(filename)
        if not os.path.exists(path):
            return jsonify({"status": "error", "error": "File not found"}), 404
        return send_file(path, mimetype="video/mp4")
    except Exception as e:
        return jsonify({"status": "error", "error": str(e)}), 500

@app.route("/download/<filename>")
def download(filename):
    try:
        path = file_path(filename)
        if not os.path.exists(path):
            return jsonify({"status": "error", "error": "File not found"}), 404
        return send_file(path, as_attachment=True)
    except Exception as e:
        return jsonify({"status": "error", "error": str(e)}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5002)
